package com.hakif.StoryApp.data.network.response

data class RegisterResponse(
	val error: Boolean,
	val message: String
)

