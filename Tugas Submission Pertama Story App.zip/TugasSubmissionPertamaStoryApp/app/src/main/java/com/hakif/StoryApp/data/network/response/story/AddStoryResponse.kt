package com.hakif.StoryApp.data.network.response.story

data class AddStoryResponse(
	val error: Boolean,
	val message: String
)

